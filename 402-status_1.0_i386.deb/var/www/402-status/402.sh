#!/bin/bash

echo 'Status: 402 Payment Required'
printf "Content-Type: text/html\n\n"
echo '<h1>GOT MONEY FOR BASH?</h1>'
