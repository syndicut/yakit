?package(402-status):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="402-status" command="/usr/bin/402-status"
