#!/usr/bin/perl

print "Status: 402 Payment Required\n";
print "Content-Type: text/html\n\n";
print "<h1>GOT MONEY FOR PERL?</h1>\n";
