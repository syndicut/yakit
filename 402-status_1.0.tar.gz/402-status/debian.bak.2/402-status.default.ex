# Defaults for 402-status initscript
# sourced by /etc/init.d/402-status
# installed at /etc/default/402-status by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
