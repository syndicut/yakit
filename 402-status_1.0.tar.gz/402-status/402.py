#!/usr/bin/python

print 'Status: 402 Payment Required'
print "Content-Type: text/html\n"
print '<h1>GOT MONEY FOR GUIDO?</h1>'
